/**
 * apiSiswa - REST API standalone (tidak bergantung ke bot).
 *
 * Metode  : GET
 * Endpoint: /?npsn=<npsn-sekolah>
 * Contoh  : http://localhost:3000/?npsn=20104653
 *
 * Alur:
 *   1. Cari data sekolah dari API sekolah (NPSN -> id sekolah).
 *   2. Ambil data siswa lewat Chrome asli yang menembus SafeLine WAF
 *      (fetch_siswa.js milik folder ini).
 *   3. Simpan hasilnya sebagai <nama-sekolah>.json di folder hasil/.
 *   4. Balas request dengan isi data.
 *
 * Respons:
 *   200 { status:"ok", npsn, sekolah:{...}, jumlah, file, data:[...] }
 *   400 { status:"error", kode:"param_npsn_hilang" }
 *   404 { status:"error", kode:"sekolah_tidak_ditemukan" }
 *   502 { status:"error", kode:"fetch_gagal" }
 *
 * Env:
 *   PORT            (default 3000)
 *
 * Jalankan: node apiSiswa/server.js
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const { spawn } = require("child_process");

const PORT = Number(process.env.PORT || 3000);
const DIR_INI = __dirname;
const FILE_FETCH = path.join(DIR_INI, "fetch_siswa.js");
const FOLDER_HASIL = path.join(DIR_INI, "hasil");
const FILE_SESSION_WAF = path.join(DIR_INI, "waf_session.json");
const BROWSER_TIMEOUT = 300; // detik

// Cookie datadik (session login yang dipakai browser)
const COOKIES = {
  BNI_persistence: "loBsixwO2PznD3anBe3G7iGGItiIlJeSoqOEU0WHOQeppAcllasC4GWDdG2PDrlBr62YmZNZyRkI6eBCgGkbyg==",
  djanCook: "eyJzZXNzaWQiOiJEQjJGMTQ3NC0xQjBFLTRCMzQtODVFQS1BOEEyMDNFNThBQzUiLCJwaWQiOiJCQkI2QkFCMC0zRTZGLTQ1MzMtOTUzMy00MDIzQjQwQTEzOTIiLCJ1c2VyIjoiYnVkaXByYXRhbWExMjEyMDFAZ21haWwuY29tIiwidHlwZSI6IjgiLCJuYW1hIjoiYnVkaXByYXRhbWEiLCJsZW1iYWdhIjpudWxsLCJ3aWxheWFoIjoiMTkwMzAwIiwic2Vrb2xhaCI6bnVsbCwiZXhwIjowfQ%3D%3D",
};

const BASE = "https://datadik.kemendikdasmen.go.id";

// ================== util ==================
function logPesan(...a) {
  console.error(`[apiSiswa ${new Date().toISOString()}]`, ...a);
}

function kirimJson(res, kode, objek) {
  const body = JSON.stringify(objek);
  res.writeHead(kode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

/** Nama file yang aman dari nama sekolah, mis. "sman-1-jakarta.json" */
function namaFileDariSekolah(nama) {
  const bersih = String(nama || "sekolah")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
  return `${bersih || "sekolah"}.json`;
}

// ================== cari sekolah (NPSN -> id) ==================
async function getSekolahByNpsn(npsn) {
  const url = `https://api-sekolah-indonesia.vercel.app/sekolah?npsn=${encodeURIComponent(npsn)}`;
  const r = await fetch(url, { signal: AbortSignal.timeout(20000) });
  const data = await r.json();
  if (data.status !== "success" || !Array.isArray(data.dataSekolah) || data.dataSekolah.length === 0) {
    return null;
  }
  return data.dataSekolah[0];
}

// ================== fetch siswa (Chrome asli, lolos WAF) ==================
function fetchSiswa(sekId) {
  return new Promise((resolve) => {
    const url = `${BASE}/ma74/sekolahpd/${sekId}/1`;
    const env = {
      ...process.env,
      DATADIK_COOKIES: JSON.stringify(COOKIES),
      DATADIK_SESSION_FILE: FILE_SESSION_WAF,
    };
    const proc = spawn("node", [FILE_FETCH, url], { env, cwd: DIR_INI });

    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      logPesan(`browser timeout ${BROWSER_TIMEOUT}s, dibunuh`);
      proc.kill("SIGKILL");
    }, BROWSER_TIMEOUT * 1000);

    proc.stdout.on("data", (d) => (stdout += d));
    proc.stderr.on("data", (d) => (stderr += d));
    proc.on("error", (e) => {
      clearTimeout(timer);
      logPesan("gagal spawn browser:", e.message);
      resolve(null);
    });
    proc.on("close", () => {
      clearTimeout(timer);
      if (stderr.trim()) console.error(stderr.trim());
      const out = stdout.trim();
      if (!out) return resolve(null);
      try {
        const data = JSON.parse(out);
        if (data && typeof data === "object" && !Array.isArray(data)) {
          logPesan(`browser gagal: ${data.error}`);
          return resolve(null);
        }
        resolve(data);
      } catch {
        logPesan("keluaran browser bukan JSON");
        resolve(null);
      }
    });
  });
}

// ================== antrian: satu Chrome pada satu waktu ==================
let antrian = Promise.resolve();
function antre(tugas) {
  const hasil = antrian.then(() => tugas());
  antrian = hasil.catch(() => {});
  return hasil;
}

// ================== inti per request ==================
async function prosesRequest(res, npsn) {
  if (!npsn || !/^\d{5,12}$/.test(npsn)) {
    return kirimJson(res, 400, {
      status: "error",
      kode: "param_npsn_hilang",
      pesan: "Gunakan: GET /?npsn=<npsn-sekolah> (5-12 digit)",
    });
  }

  logPesan("cari sekolah npsn", npsn);
  const sekolah = await getSekolahByNpsn(npsn);
  if (!sekolah || !sekolah.id) {
    return kirimJson(res, 404, { status: "error", kode: "sekolah_tidak_ditemukan", npsn });
  }

  logPesan(`fetch siswa "${sekolah.sekolah}" (${sekolah.id})`);
  const siswa = await fetchSiswa(sekolah.id);
  if (!siswa) {
    return kirimJson(res, 502, {
      status: "error",
      kode: "fetch_gagal",
      npsn,
      pesan: "Gagal mengambil data (WAF/browser). Coba lagi nanti.",
    });
  }

  // 1) simpan hasil sebagai <nama-sekolah>.json
  fs.mkdirSync(FOLDER_HASIL, { recursive: true });
  const namaFile = namaFileDariSekolah(sekolah.sekolah);
  const pathFile = path.join(FOLDER_HASIL, namaFile);
  const isi = {
    npsn,
    sekolah: {
      id: sekolah.id,
      nama: sekolah.sekolah,
      propinsi: sekolah.propinsi,
      kabupaten_kota: sekolah.kabupaten_kota,
      kecamatan: sekolah.kecamatan,
      jenjang: sekolah.bentuk_pendidikan,
      status: sekolah.status,
    },
    jumlah: siswa.length,
    diambil_pada: new Date().toISOString(),
    data: siswa,
  };
  fs.writeFileSync(pathFile, JSON.stringify(isi, null, 2), "utf8");
  logPesan(`tersimpan: ${pathFile}`);

  // 2) balas request
  kirimJson(res, 200, {
    status: "ok",
    npsn,
    sekolah: isi.sekolah,
    jumlah: siswa.length,
    file: namaFile,
    path_file: pathFile,
    data: siswa,
  });
}

// ================== server ==================
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method !== "GET") {
    return kirimJson(res, 405, { status: "error", kode: "metode_tidak_didukung", pesan: "Hanya metode GET" });
  }

  const npsn = url.searchParams.get("npsn");
  if (!npsn) {
    return kirimJson(res, 400, {
      status: "error",
      kode: "param_npsn_hilang",
      pesan: "Gunakan: GET /?npsn=<npsn-sekolah>",
    });
  }

  antre(() => prosesRequest(res, npsn)).catch((e) => {
    logPesan("error tak terduga:", e && e.message);
    if (!res.headersSent) kirimJson(res, 500, { status: "error", kode: "kesalahan_server" });
  });
});

if (!fs.existsSync(FILE_FETCH)) {
  console.error(`[apiSiswa] fetch_siswa.js tidak ditemukan: ${FILE_FETCH}`);
  process.exit(1);
}

server.listen(PORT, () => {
  logPesan(`API siap di http://localhost:${PORT}/?npsn=<npsn>`);
});
