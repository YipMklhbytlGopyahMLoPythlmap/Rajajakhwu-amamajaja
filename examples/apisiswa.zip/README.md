# apiSiswa

REST API untuk mengambil data siswa dari Datadik (kemendikdasmen.go.id) lewat browser anti-detect **Camoufox** (Firefox) — lolos SafeLine WAF level 2.

## Endpoint

```
GET /?npsn=<npsn-sekolah>
```

Contoh: `http://localhost:3000/?npsn=20104653`

## Install & Run (Ubuntu VPS — tanpa display)

```bash
# 1. Update & install dependensi
sudo apt update && sudo apt upgrade -y
sudo apt install -y xvfb wget unzip

# 2. Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 3. Install pm2 & cloudflared
npm i -g pm2
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
rm cloudflared-linux-amd64.deb

# 4. Download & install project
cd /root
wget -O apisiswa.zip "<URL-ZIP-KAMU>"
unzip -o apisiswa.zip -d apisiswa
cd apisiswa
npm install
npx camoufox-js fetch    # download browser Camoufox (~1.3 GB, sekali saja)

# 5. Cek syntax
node --check server.js
node --check fetch_siswa.js

# 6. Jalankan dengan pm2 + xvfb (virtual display)
pm2 delete myserver tunnel 2>/dev/null
pm2 start /usr/bin/xvfb-run --name myserver --interpreter none -- -a node server.js
pm2 start /usr/local/bin/cloudflared --name tunnel --interpreter none -- tunnel --no-autoupdate --url http://127.0.0.1:3000
pm2 save

# 7. Test
sleep 4
curl -s -w '\nHTTP %{http_code} (%{time_total}s)\n' 'http://localhost:3000/?npsn=20508544'
pm2 list
pm2 logs myserver --lines 20 --nostream

# 8. Ambil URL Cloudflare Tunnel
pm2 logs tunnel --lines 50 --nostream | grep -oP 'https://[a-z0-9-]+\.trycloudflare\.com'
```

## Install & Run (Windows)

```bash
npm install
npx camoufox-js fetch
node server.js
```

Buka: `http://localhost:3000/?npsn=20508544`

## Env

| Variabel | Default | Keterangan |
|---|---|---|
| `PORT` | `3000` | Port server |
| `DATADIK_HEADLESS` | `0` | `1` = headless (Linux pakai xvfb) |
| `DATADIK_TIMEOUT_MS` | `240000` | Timeout browser (ms) |
| `DATADIK_SLIDER_ATTEMPTS` | `3` | Percobaan slider WAF |

## Struktur

```
├── server.js        # HTTP server + API
├── fetch_siswa.js   # Browser Camoufox + slider WAF
├── package.json
└── hasil/           # Output JSON per sekolah (otomatis)
```

## Cara kerja

1. Cari sekolah dari NPSN via API Indonesia
2. Buka endpoint Datadik di Camoufox (Firefox anti-detect)
3. Selesaikan slider SafeLine WAF (drag pelan seperti manusia)
4. Ambil JSON data siswa → simpan ke `hasil/<nama-sekolah>.json`
