/**
 * Ambil data siswa datadik lewat Camoufox (Firefox anti-detect).
 *
 * Kenapa Camoufox: SafeLine WAF level 2 mendeteksi Chrome/CDP
 * ("Debugging Detected"). Camoufox adalah Firefox build anti-detect
 * dengan fingerprint asli dari C++ dan Playwright protocol yang
 * tidak terlihat oleh halaman.
 *
 * Pemakaian:
 *   node fetch_siswa.js "<url-lengkap-endpoint-siswa>"
 *
 * Output: JSON data siswa ke stdout. Semua log/error ke stderr.
 * Env: DATADIK_COOKIES, DATADIK_SESSION_FILE,
 *      DATADIK_HEADLESS=1, DATADIK_TIMEOUT_MS.
 */
const fs = require("fs");
const path = require("path");

const url = process.argv[2];
if (!url) {
  console.error("[fetch_siswa] URL tujuan wajib dikirim sebagai argumen");
  process.exit(2);
}

const COOKIE_DOMAIN = process.env.DATADIK_COOKIE_DOMAIN || ".kemendikdasmen.go.id";
const BASE_COOKIES = JSON.parse(process.env.DATADIK_COOKIES || "{}");
const SESSION_FILE = process.env.DATADIK_SESSION_FILE || "";
const HEADLESS = process.env.DATADIK_HEADLESS === "1";
const TIMEOUT_MS = Number(process.env.DATADIK_TIMEOUT_MS || 240000);
const MAX_SLIDER_ATTEMPT = Number(process.env.DATADIK_SLIDER_ATTEMPTS || 3);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rand = (a, b) => a + Math.random() * (b - a);
const log = (...a) => console.error("[fetch_siswa]", ...a);

function loadSessionCookies() {
  if (!SESSION_FILE) return [];
  try {
    return JSON.parse(fs.readFileSync(SESSION_FILE, "utf8"));
  } catch {
    return [];
  }
}

function saveSessionCookies(cookies) {
  if (!SESSION_FILE) return;
  try {
    const bersih = cookies.map(({ name, value, domain, path: p }) => ({
      name, value, domain, path: p || "/",
    }));
    fs.writeFileSync(SESSION_FILE, JSON.stringify(bersih, null, 2));
  } catch (e) {
    log("gagal simpan session:", e.message);
  }
}

/** Geometri elemen slider via Playwright evaluate (aman di Camoufox). */
async function ukurSlider(page) {
  return page.evaluate(() => {
    const g = (id) => {
      const e = document.getElementById(id);
      if (!e) return null;
      const r = e.getBoundingClientRect();
      return { x: r.x, y: r.y, w: r.width, h: r.height, cx: r.x + r.width / 2, cy: r.y + r.height / 2 };
    };
    return {
      bar: g("sl-slide-bar"),
      target: g("sl-slide-target"),
      knob: g("sl-slider"),
      text: (document.getElementById("sl-text") || {}).innerText || "",
      err: (document.getElementById("sl-error-msg") || {}).innerText || "",
    };
  });
}

/**
 * Drag pelan seperti manusia.
 */
async function dragSlider(page, startX, startY, deltaX) {
  await page.mouse.move(startX - rand(40, 90), startY + rand(20, 60), { steps: 6 });
  await sleep(rand(120, 260));
  await page.mouse.move(startX, startY, { steps: 4 });
  await sleep(rand(150, 300));
  await page.mouse.down();
  await sleep(rand(220, 380));

  const steps = 60;
  const durasi = rand(1100, 1600);
  for (let i = 1; i <= steps; i++) {
    const p = i / steps;
    const ease = 1 - Math.pow(1 - p, 3);
    await page.mouse.move(startX + deltaX * ease, startY + Math.sin(p * Math.PI) * rand(-2, 2));
    await sleep(durasi / steps + rand(-4, 6));
  }
  await sleep(rand(250, 450));
  await page.mouse.up();
}

/** Selesaikan slider SafeLine. */
async function selesaikanSlider(page) {
  for (let attempt = 1; attempt <= MAX_SLIDER_ATTEMPT; attempt++) {
    await page.waitForSelector("#sl-slider", { timeout: 20000 }).catch(() => {});
    await sleep(1200);

    const geo = await ukurSlider(page).catch(() => null);
    if (!geo || !geo.knob) {
      log(`slider tidak ada (percobaan ${attempt})`);
      return true; // mungkin sudah lolos
    }

    const sx = geo.knob.cx;
    const sy = geo.knob.cy;

    // Hold: SafeLine membuka target
    await page.mouse.move(sx, sy, { steps: 3 });
    await sleep(rand(180, 280));
    await page.mouse.down();
    await sleep(rand(350, 550));

    const held = await ukurSlider(page).catch(() => null);
    await page.mouse.up();
    await sleep(rand(700, 1000));

    const t = (held && held.target) || geo.target;
    const knobAfter = (held && held.knob) || geo.knob;
    const delta = t ? t.cx - knobAfter.cx : null;

    log(`percobaan ${attempt}: knob=${sx.toFixed(0)} target=${t ? t.cx.toFixed(0) : "?"} delta=${delta ? delta.toFixed(0) : "?"} teks="${(held && held.text) || ""}"`);

    if (delta == null || !(delta > 30 && delta < 2000)) {
      log("  delta tidak wajar");
      continue;
    }

    await dragSlider(page, knobAfter.cx, knobAfter.cy, delta);
    log("  drag selesai, tunggu verifikasi...");

    // Tunggu challenge hilang
    for (let i = 0; i < 20; i++) {
      await sleep(1000);
      const ada = await page.$("#sl-slide-bar").catch(() => null);
      if (!ada) {
        log(`  challenge hilang di detik ${i + 1}`);
        return true;
      }
      const err = await page.$("#sl-error-msg").catch(() => null);
      if (err) {
        const teks = await err.innerText().catch(() => "");
        if (/too fast|slow down|debug/i.test(teks)) log(`  WAF: ${teks}`);
      }
    }
    log("  challenge masih ada, coba ulang");
  }
  return false;
}

async function main() {
  const { Camoufox } = await import("camoufox-js");

  log("meluncurkan Camoufox...");
  const browser = await Camoufox({
    headless: HEADLESS,
    os: process.platform === "win32" ? "windows" : "linux",
  });
  await sleep(1500); // tunggu browser stabil

  const timer = setTimeout(async () => {
    log(`timeout ${TIMEOUT_MS}ms, menutup browser`);
    try { await browser.close(); } catch {}
    process.exit(1);
  }, TIMEOUT_MS);

  try {
    const page = await browser.newPage();
    const context = page.context();

    // cookie dari bot + session WAF
    const session = loadSessionCookies();
    const semua = [];
    for (const c of session) {
      semua.push({
        name: c.name,
        value: c.value,
        domain: c.domain || COOKIE_DOMAIN,
        path: c.path || "/",
      });
    }
    for (const [name, value] of Object.entries(BASE_COOKIES)) {
      semua.push({ name, value, domain: COOKIE_DOMAIN, path: "/" });
    }
    if (semua.length > 0) await context.addCookies(semua);

    let resp = null;
    for (let ronde = 1; ronde <= 3; ronde++) {
      try {
        resp = await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
      } catch (e) {
        log(`ronde ${ronde}: goto gagal: ${e.message}`);
        await sleep(3000);
        continue;
      }
      const status = resp ? resp.status() : 0;
      log(`ronde ${ronde}: status ${status}`);
      if (status !== 468) break;

      await selesaikanSlider(page);

      // re-goto setelah slider
      try {
        resp = await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
        log(`ronde ${ronde} ulang: status ${resp ? resp.status() : "?"}`);
      } catch (e) {
        log(`ronde ${ronde} ulang gagal: ${e.message}`);
      }
    }

    if (!resp) {
      console.log(JSON.stringify({ error: "goto_failed" }));
      process.exit(1);
    }
    const statusAkhir = resp.status();
    if (statusAkhir !== 200) {
      log("status tidak 200:", statusAkhir);
      console.log(JSON.stringify({ error: `http_${statusAkhir}` }));
      process.exit(1);
    }

    const teks = await page.evaluate(() => document.body.innerText);
    const data = JSON.parse(teks);
    saveSessionCookies(await context.cookies());
    process.stdout.write(JSON.stringify(data));
  } finally {
    clearTimeout(timer);
    try { await browser.close(); } catch {}
  }
}

main().catch((e) => {
  log("error:", e && e.message ? e.message : e);
  console.log(JSON.stringify({ error: String((e && e.message) || e) }));
  process.exit(1);
});
